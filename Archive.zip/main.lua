-- Game Configuration
TARGET_SCORE = 1  -- Target score for all rounds (change this to adjust difficulty)

function love.load()
    love.window.setTitle("Domino Deckbuilder")

    local screenWidth = love.graphics.getWidth()
    local screenHeight = love.graphics.getHeight()
    
    if love.system.getOS() == "Android" or love.system.getOS() == "iOS" then
        love.window.setFullscreen(true)
        screenWidth = love.graphics.getWidth()
        screenHeight = love.graphics.getHeight()
    else
        -- Enable window resizing for desktop platforms
        love.window.setMode(screenWidth, screenHeight, {resizable = true})
    end
    
    love.graphics.setDefaultFilter("nearest", "nearest")
    
    require("game.domino")
    require("game.hand")
    require("game.board")
    require("game.validation")
    require("game.scoring")
    require("game.challenges")
    require("game.map")
    require("game.save")
    require("game.tools")
    require("ui.touch")
    require("ui.layout")
    require("ui.fonts")
    require("ui.colors")
    require("ui.renderer")
    require("ui.animation")
    require("ui.audio")
    require("ui.title_screen")
    
    loadDominoSprites()
    loadDemonTileSprites()
    loadTitleScreenSprites()
    loadNodeSprites()
    loadCoinSprite()
    loadCandleSprites()
    loadToolSprites()
    loadCupSprites()
    
    gameState = {
        screen = {
            width = screenWidth,
            height = screenHeight,
            scale = math.min(screenWidth / 800, screenHeight / 600)
        },
        deck = {},
        hand = {},
        board = {},
        placedTiles = {},
        score = 0,
        gamePhase = "playing",
        placementOrder = {},
        discardsUsed = 0,
        maxDiscardsPerRound = 2,  -- Base discards per round
        playsUsed = 0,
        handsPlayed = 0,
        currentRound = 1,
        baseTargetScore = TARGET_SCORE,
        targetScore = TARGET_SCORE,
        maxHandsPerRound = 3,
        scoringSequence = nil,
        currentMap = nil,
        selectedNode = nil,  -- For node confirmation dialog
        isBossRound = false,  -- Track if current combat is the boss round
        currentDay = 1,  -- Track which map/day the player is on
        scoreAnimation = {    -- Animation properties for score display
            scale = 1.0,
            shake = 0,
            color = {UI.Colors.FONT_RED[1], UI.Colors.FONT_RED[2], UI.Colors.FONT_RED[3], UI.Colors.FONT_RED[4]}
        },
        scoreIdleAnimation = {  -- Idle floating animation for score
            floatOffset = 0,
            phase = 0  -- Random phase offset for variety
        },
        displayedRemainingScore = 1,  -- Score display value for countdown animation
        scoreCountdownSpeed = 0,  -- Speed of countdown animation (points per second)
        -- Victory phrase animation system
        victoryPhrase = nil,  -- Current victory phrase text
        victoryPhraseAnimation = {  -- Animation properties for victory phrase
            xOffset = -500,  -- Start off-screen left
            opacity = 0,
            scale = 1.0
        },
        -- Next button (NEXT >>) animation system
        nextButtonText = "NEXT>",
        nextButtonAnimation = {
            color = {0.941, 0.576, 0.608, 1}  -- FONT_PINK initially
        },
        nextButtonBounds = nil,  -- Clickable area bounds
        -- Node confirmation NEXT> button animation
        nodeConfirmationNextButtonAnimation = {
            color = {0.941, 0.576, 0.608, 1}  -- FONT_PINK initially
        },
        nodeConfirmationNextButton = nil,  -- Clickable area bounds
        -- Formula display animation system
        formulaDisplayValue = 0,  -- Currently displayed formula value (for counting animation)
        formulaTargetValue = 0,  -- Target value to count toward
        formulaCountSpeed = 0,  -- Speed of formula counting (points per second)
        formulaAnimation = {  -- Animation properties for formula display
            scale = 1.0,
            shake = 0,
            opacity = 1.0,
            yOffset = 0,  -- For transfer animation
            color = {1, 0.8, 0.2, 1}  -- Gold by default
        },
        -- Currency system
        coins = 0,  -- Starting currency
        startRoundCoins = 0,  -- Coins at start of round for bonus calculation
        coinsAnimation = {    -- Animation properties for coins display
            scale = 1.0,
            shake = 0,
            color = {1, 0.9, 0.3, 1},  -- Gold color
            coinFlips = {},  -- Random horizontal flips for each coin sprite
            fallingCoins = {},  -- Array of coins currently animating
            settledCoins = 0,  -- Number of coins that finished animating
            targetCoins = 0,  -- Final target coin count
            chipLoopActive = false,  -- Whether chip loop sound should be playing
            firstCoinLanded = false  -- Track when first coin lands to start sound
        },
        -- Coin breakdown display (shown to the right of money counter)
        coinBreakdown = {},  -- Array of {text = "+2$ hands", opacity = 1.0, coins = 2, animated = false, yOffset = 0}
        coinBreakdownQueue = {},  -- Queue of breakdown items waiting to animate sequentially
        -- Deckbuilding system
        tileCollection = {},  -- All tiles the player has unlocked
        offeredTiles = {},    -- Tiles currently being offered in tiles menu
        selectedTileOffer = nil,  -- Currently selected tile in the offering
        selectedTilesToBuy = {},  -- Tiles selected for purchase (multi-select)
        -- Tile fusion system
        tilesMenuMode = "shop",  -- "shop" or "fusion"
        fusionHand = {},  -- 7-tile hand for fusion mode
        fusionSlotTiles = {},  -- {tile1, tile2} - actual tiles in fusion slots
        -- Challenge system
        activeChallenges = {},  -- Active challenges for current combat
        challengeStates = {},  -- State data for each challenge
        maxTilesCounterAnimation = {  -- Animation for max tiles counter
            color = {UI.Colors.FONT_WHITE[1], UI.Colors.FONT_WHITE[2], UI.Colors.FONT_WHITE[3], UI.Colors.FONT_WHITE[4]},
            scale = 1.0
        },
        bannedNumberCounterAnimation = {  -- Animation for banned number counter
            color = {UI.Colors.FONT_WHITE[1], UI.Colors.FONT_WHITE[2], UI.Colors.FONT_WHITE[3], UI.Colors.FONT_WHITE[4]},
            scale = 1.0
        },
        -- Settings system
        settingsMenuOpen = false,  -- Track if settings menu is open
        musicEnabled = true,  -- Track music state
        sfxEnabled = true,  -- Track sound effects state
        -- Tools/Artifacts system
        ownedTools = {},  -- Array of owned tool IDs (max 3, can have duplicates)
        transformerSelectionMode = false,  -- Track if player is selecting a tile to transform
        obsidianTransmuterSelectionMode = false,  -- Track if player is selecting a tile to transmute to obsidian
        tenderTransmuterSelectionMode = false,  -- Track if player is selecting a tile to transmute to tender
        toolButtonBounds = {},  -- Array of clickable bounds for tool buttons (DEPRECATED - use toolSpriteBounds)
        toolSpriteBounds = {},  -- Array of clickable bounds for tool sprites
        toolStackAnimation = {  -- Animation state for selected tool
            isActivated = false,
            selectedToolIndex = nil,  -- Index in ownedTools array of selected tool
            animationProgress = 0,  -- 0-1 progress of bounce/tilt animation
            scale = 1.0,  -- Current scale multiplier
            tiltAngle = 0  -- Current rotation in radians
        },
        toolStackExplosion = {  -- Tower explosion/separation state
            isExploded = false,
            explosionProgress = 0,  -- 0-1 animation progress (0=stacked, 1=exploded)
            isCollapsing = false,  -- Animating back to stacked
            idleAnimations = {}  -- Per-tool idle animation state {[index] = {floatOffset, tiltAngle, phase}}
        },
        draggedTool = nil,  -- Currently dragged tool data {toolId, toolIndex, spriteType, visualX, visualY}
        toolSpritePositions = nil,  -- Animated positions during gravity {[index] = {visualX, visualY, scale}}
        activeDieSprites = {},  -- Persistent dice on board {x, y, rotation, scale, spriteType, toolId}
        -- Win sequence tracking
        winSequenceTriggered = false,  -- Track if win sequence already started
        -- Title screen animation system
        titleTiles = {},  -- Array of 4 animated domino tiles for DEMOMINO
        titleTilesInitialized = false,  -- Track if title tiles have been set up
        titleNewGameButtonAnimation = {
            color = {0.941, 0.576, 0.608, 1}  -- FONT_PINK
        },
        titleContinueButtonAnimation = {
            color = {0.941, 0.576, 0.608, 1}  -- FONT_PINK
        }
    }
    
    UI.Fonts.load()
    UI.Audio.load()

    -- Load CRT shader and create render canvas with depth/stencil support for fog of war
    crtShader = love.graphics.newShader("shaders/background_crt.glsl")
    mainCanvas = love.graphics.newCanvas(screenWidth, screenHeight, {format = "rgba8", readable = true, msaa = 0})

    -- Start at title screen instead of initializing game directly
    gameState.gamePhase = "title_screen"

    -- Start background music
    UI.Audio.playMusic()
end

-- Reset the entire game to a fresh state (like starting a new run)
function resetGameToFresh()
    -- Delete any existing save
    Save.deleteSave()

    -- Reset ALL game state completely
    gameState.currentRound = 1
    gameState.targetScore = TARGET_SCORE
    gameState.coins = 0
    gameState.startRoundCoins = 0
    gameState.tileCollection = Domino.createStarterCollection()
    gameState.currentMap = nil
    gameState.isBossRound = false

    -- Reset shop/menu state
    gameState.offeredTiles = {}
    gameState.selectedTileOffer = nil
    gameState.selectedTilesToBuy = {}

    -- Reset fusion state
    gameState.tilesMenuMode = "shop"
    gameState.fusionHand = {}
    gameState.fusionSlotTiles = {}

    -- Reset challenges
    gameState.activeChallenges = {}
    gameState.challengeStates = {}

    -- Reset tools/artifacts
    gameState.ownedTools = {}

    -- Reset coin animation state
    gameState.coinsAnimation = {
        scale = 1.0,
        shake = 0,
        color = {1, 0.9, 0.3, 1},
        coinFlips = {},
        fallingCoins = {},
        settledCoins = 0,
        targetCoins = 0
    }

    -- Initialize a fresh game
    initializeGame(false)

    -- Generate new map
    gameState.currentMap = Map.generateMap(gameState.screen.width, gameState.screen.height, gameState.currentRound)
end

function initializeGame(isNewRound)
    isNewRound = isNewRound or false

    -- Initialize tile collection on first run
    if not gameState.tileCollection or #gameState.tileCollection == 0 then
        gameState.tileCollection = Domino.createStarterCollection()
    end

    -- Create deck from player's collection
    gameState.deck = Domino.createDeckFromCollection(gameState.tileCollection)
    Domino.shuffleDeck(gameState.deck)

    -- Initialize empty hand first
    gameState.hand = {}

    -- Draw tiles from deck
    for i = 1, 7 do
        local tile = table.remove(gameState.deck, 1)
        if tile then
            tile.selected = false
            tile.placed = false
            table.insert(gameState.hand, tile)
        end
    end

    -- Sort hand BEFORE animating so tiles animate to their final sorted positions
    Hand.sortByValue(gameState.hand)
    -- Mark signature to prevent re-sorting during first update
    gameState.hand._lastSignature = Hand.getHandSignature(gameState.hand)

    -- Animate initial tiles drawing from right
    Hand.animateTilesDraw(gameState.hand, 0)

    gameState.board = {}
    gameState.placedTiles = {}
    gameState.score = 0
    gameState.previousScore = 0
    gameState.selectedTiles = {}
    gameState.placementOrder = {}
    gameState.discardsUsed = 0
    gameState.playsUsed = 0
    gameState.handsPlayed = 0
    gameState.scoreAnimation = nil
    gameState.activeDieSprites = {}  -- Clear dice from previous round
    gameState.buttonAnimations = {
        playButton = {scale = 1.0, pressed = false, yOffset = 0},
        discardButton = {scale = 1.0, pressed = false, yOffset = 0},
        sortButton = {scale = 1.0, pressed = false, yOffset = 0}
    }
    gameState.maxTilesCounterAnimation = {
        color = {UI.Colors.FONT_WHITE[1], UI.Colors.FONT_WHITE[2], UI.Colors.FONT_WHITE[3], UI.Colors.FONT_WHITE[4]},
        scale = 1.0
    }
    gameState.bannedNumberCounterAnimation = {
        color = {UI.Colors.FONT_WHITE[1], UI.Colors.FONT_WHITE[2], UI.Colors.FONT_WHITE[3], UI.Colors.FONT_WHITE[4]},
        scale = 1.0
    }

    -- If not a new round, reset everything including round progress
    if not isNewRound then
        gameState.currentRound = 1
    end

    -- Target score is always fixed
    gameState.targetScore = TARGET_SCORE

    -- Initialize score display animations
    gameState.displayedRemainingScore = gameState.targetScore
    gameState.scoreCountdownSpeed = 0
    gameState.scoreIdleAnimation = {
        floatOffset = 0,
        phase = love.math.random() * 2 * math.pi  -- Random phase for variety
    }

    -- Position tiles will be handled in first draw call
end

function initializeCombatRound()
    -- Reset only combat-specific state while preserving map progress and tile collection

    -- STEP 1: Clear old combat state FIRST
    gameState.board = {}
    gameState.placedTiles = {}
    gameState.hand = {}
    gameState.score = 0
    gameState.previousScore = 0
    gameState.selectedTiles = {}
    gameState.placementOrder = {}
    gameState.discardsUsed = 0
    gameState.maxDiscardsPerRound = 2  -- Reset to base value
    gameState.playsUsed = 0
    gameState.handsPlayed = 0
    gameState.scoreAnimation = nil
    gameState.winSequenceTriggered = false  -- Reset win sequence flag
    gameState.activeDieSprites = {}  -- Clear dice from previous round
    gameState.buttonAnimations = {
        playButton = {scale = 1.0, pressed = false, yOffset = 0},
        discardButton = {scale = 1.0, pressed = false, yOffset = 0},
        sortButton = {scale = 1.0, pressed = false, yOffset = 0}
    }
    gameState.maxTilesCounterAnimation = {
        color = {UI.Colors.FONT_WHITE[1], UI.Colors.FONT_WHITE[2], UI.Colors.FONT_WHITE[3], UI.Colors.FONT_WHITE[4]},
        scale = 1.0
    }
    gameState.bannedNumberCounterAnimation = {
        color = {UI.Colors.FONT_WHITE[1], UI.Colors.FONT_WHITE[2], UI.Colors.FONT_WHITE[3], UI.Colors.FONT_WHITE[4]},
        scale = 1.0
    }

    -- Reset next button animation color to pink
    gameState.nextButtonAnimation = {
        color = {0.941, 0.576, 0.608, 1}  -- FONT_PINK
    }

    -- Clear coin breakdown display
    gameState.coinBreakdown = {}
    gameState.coinBreakdownQueue = {}

    -- Track coins at start of round for bonus calculation
    gameState.startRoundCoins = gameState.coins

    -- Initialize score display animations
    gameState.displayedRemainingScore = gameState.targetScore
    gameState.scoreCountdownSpeed = 0
    gameState.scoreIdleAnimation = {
        floatOffset = 0,
        phase = love.math.random() * 2 * math.pi  -- Random phase for variety
    }

    -- Reset victory phrase from previous round
    gameState.victoryPhrase = nil
    gameState.victoryPhraseAnimation = {
        xOffset = -500,
        opacity = 0,
        scale = 1.0
    }

    -- STEP 2: Create fresh deck from player's collection
    gameState.deck = Domino.createDeckFromCollection(gameState.tileCollection)
    Domino.shuffleDeck(gameState.deck)

    -- STEP 3: Initialize challenges (can now take a tile from deck for anchor)
    Challenges.initialize(gameState)

    -- STEP 4: Draw tiles from deck to hand
    for i = 1, 7 do
        local tile = table.remove(gameState.deck, 1)
        if tile then
            tile.selected = false
            tile.placed = false
            table.insert(gameState.hand, tile)
        end
    end

    -- STEP 5: Sort hand BEFORE animating so tiles animate to their final sorted positions
    Hand.sortByValue(gameState.hand)
    -- Mark signature to prevent re-sorting during first update
    gameState.hand._lastSignature = Hand.getHandSignature(gameState.hand)

    -- STEP 6: Animate tiles drawing from right
    Hand.animateTilesDraw(gameState.hand, 0)

    -- STEP 7: Arrange board tiles (including anchor) to ensure proper positioning
    if #gameState.placedTiles > 0 then
        Board.arrangePlacedTiles()
    end

    -- STEP 8: Reset tool usages for new combat round
    Tools.resetUsages(gameState)

    -- Keep currentRound, targetScore, currentMap, tileCollection, and ownedTools unchanged
    -- These should persist across combat rounds
end

function triggerVictoryPhrase()
    local phrases = {
        "TOTAL DOMINATION",
        "DOMINO EFFECT",
        "CHAIN REACTION",
        "CONNECTING THE DOTS",
        "SPOT ON!",
        "PIP PERFECT",
        "BONE TO PICK",
        "BAD TO THE BONE",
        "DOMINATRIX",
        "DO RE MI NO",
        "DOMINATING!"
    }

    -- Select random phrase
    gameState.victoryPhrase = phrases[love.math.random(1, #phrases)]

    -- Reset animation state
    gameState.victoryPhraseAnimation = {
        xOffset = -500,  -- Start off-screen left
        opacity = 0,
        scale = 1.0
    }

    -- Animate in from left (like hand tiles)
    UI.Animation.animateTo(gameState.victoryPhraseAnimation, {xOffset = 0, opacity = 1}, 0.8, "easeOutBack")
end

function updateScoreIdleAnimation(dt)
    local time = love.timer.getTime()

    -- Floating animation - 3px range, 2.5 second cycle (same as hand tiles)
    local floatPhase = time * 2.5 + gameState.scoreIdleAnimation.phase
    gameState.scoreIdleAnimation.floatOffset = math.sin(floatPhase) * 3
end

function updateScoreCountdown(dt)
    -- Rapidly animate the displayed score down to the actual remaining score
    local actualRemaining = math.max(0, gameState.targetScore - gameState.score)

    if gameState.displayedRemainingScore > actualRemaining then
        -- Count down rapidly (80 points per second for smooth visual effect)
        gameState.displayedRemainingScore = gameState.displayedRemainingScore - gameState.scoreCountdownSpeed * dt

        -- Don't overshoot the target
        if gameState.displayedRemainingScore < actualRemaining then
            gameState.displayedRemainingScore = actualRemaining
            gameState.scoreCountdownSpeed = 0

            -- Stop score animation sound
            UI.Audio.stopScoreAnimating()

            -- If countdown reached 0, check if player won and trigger game end (only once)
            if actualRemaining == 0 and gameState.score >= gameState.targetScore and not gameState.winSequenceTriggered then
                gameState.winSequenceTriggered = true

                -- Start victory bell sequence (3 play_button sounds with delay)
                gameState.victoryBellSequence = {
                    timer = 0,
                    bellsPlayed = 0,
                    nextBellAt = 0
                }
            end
        end
    else
        gameState.displayedRemainingScore = actualRemaining
    end

    -- Extra safeguard: never go below 0
    gameState.displayedRemainingScore = math.max(0, gameState.displayedRemainingScore)
end

function updateVictoryBellSequence(dt)
    if not gameState.victoryBellSequence then return end

    local seq = gameState.victoryBellSequence
    seq.timer = seq.timer + dt

    -- Play bells at intervals (0s, 0.2s, 0.4s)
    if seq.timer >= seq.nextBellAt and seq.bellsPlayed < 3 then
        UI.Audio.playPlayButton()
        seq.bellsPlayed = seq.bellsPlayed + 1
        seq.nextBellAt = seq.nextBellAt + 0.2
    end

    -- After all 3 bells, wait a bit then trigger game end
    if seq.bellsPlayed >= 3 and seq.timer >= 0.8 then
        gameState.victoryBellSequence = nil
        Touch.checkGameEnd()
    end
end

function updateFormulaCountAnimation(dt)
    -- Animate the formula display value counting toward target
    if gameState.formulaDisplayValue < gameState.formulaTargetValue then
        -- Count up
        gameState.formulaDisplayValue = gameState.formulaDisplayValue + gameState.formulaCountSpeed * dt

        -- Don't overshoot
        if gameState.formulaDisplayValue > gameState.formulaTargetValue then
            gameState.formulaDisplayValue = gameState.formulaTargetValue
            gameState.formulaCountSpeed = 0
        end
    elseif gameState.formulaDisplayValue > gameState.formulaTargetValue then
        -- Count down (for multiplication animation)
        gameState.formulaDisplayValue = gameState.formulaDisplayValue - gameState.formulaCountSpeed * dt

        -- Don't overshoot
        if gameState.formulaDisplayValue < gameState.formulaTargetValue then
            gameState.formulaDisplayValue = gameState.formulaTargetValue
            gameState.formulaCountSpeed = 0
        end
    end
end

function updateScore(newScore, bonusInfo)
    if newScore ~= gameState.score then
        local difference = newScore - gameState.score
        gameState.previousScore = gameState.score
        gameState.score = newScore

        -- Trigger countdown animation (speed: points to count per second)
        -- Slower to allow sound to play out more: 60 points per second
        local remainingDifference = gameState.displayedRemainingScore - math.max(0, gameState.targetScore - newScore)
        gameState.scoreCountdownSpeed = math.max(60, remainingDifference * 1.2)  -- At least 60/sec, or faster for big changes

        -- Start score animation sound effect
        UI.Audio.playScoreAnimating()

        -- Create score popup animation
        local scoreX = gameState.screen.width - UI.Layout.scale(120)
        local scoreY = UI.Layout.scale(50)

        UI.Animation.createScorePopup(difference, scoreX, scoreY, bonusInfo and bonusInfo.hasBonus)

        -- Animate the score display itself
        gameState.scoreAnimation = {
            scale = 1.0,
            shake = 0,
            color = {UI.Colors.FONT_RED[1], UI.Colors.FONT_RED[2], UI.Colors.FONT_RED[3], UI.Colors.FONT_RED[4]}
        }

        local color = UI.Colors.FONT_RED
        if bonusInfo and bonusInfo.hasBonus then
            color = UI.Colors.FONT_RED_DARK
            gameState.scoreAnimation.shake = 3
        end

        UI.Animation.animateTo(gameState.scoreAnimation, {scale = 1.3}, 0.2, "easeOutBack", function()
            UI.Animation.animateTo(gameState.scoreAnimation, {scale = 1.0}, 0.3, "easeOutQuart")
            gameState.scoreAnimation.color = {color[1], color[2], color[3], color[4]}
            UI.Animation.animateTo(gameState.scoreAnimation, {shake = 0}, 0.5, "easeOutQuart", function()
                UI.Animation.animateTo(gameState.scoreAnimation.color, {[1] = UI.Colors.FONT_RED[1], [2] = UI.Colors.FONT_RED[2], [3] = UI.Colors.FONT_RED[3]}, 1.0, "easeOutQuart")
            end)
        end)
    end
end

function updateCoins(newCoins, bonusInfo)
    -- Use targetCoins if it exists (coins are still animating), otherwise use settled coins
    local previousTarget = gameState.coinsAnimation.targetCoins or gameState.coins
    local difference = newCoins - previousTarget

    if difference > 0 then
        -- Gaining coins - trigger falling animation
        gameState.coinsAnimation.targetCoins = newCoins
        gameState.coinsAnimation.chipLoopActive = true  -- Enable chip loop for this animation
        gameState.coinsAnimation.firstCoinLanded = false  -- Reset flag

        -- Get base position from layout (separate text and stack positions)
        local textX, textY, stackX, stackY = UI.Layout.getCoinDisplayPosition()
        local minScale = math.min(gameState.screen.width / 800, gameState.screen.height / 600)
        local spriteScale = math.max(minScale * 2.0, 1.0)

        -- Create falling coin objects for each new coin
        local oldCoins = previousTarget
        for i = 1, difference do
            local coinIndex = oldCoins + i

            -- Calculate target position in stack
            local stackIndex = math.floor((coinIndex - 1) / 15)
            local coinInStack = ((coinIndex - 1) % 15) + 1

            local coinStartX = stackX - UI.Layout.scale(20)  -- Stack starts 20px left of layout position
            local stackOffsetX = stackIndex * (8 * spriteScale)  -- Move RIGHT for new stacks
            local targetX = coinStartX + stackOffsetX
            local targetY = stackY - ((coinInStack - 1) * 4 * spriteScale)

            -- Random horizontal starting offset for variety
            local randomXOffset = (love.math.random() - 0.5) * UI.Layout.scale(100)

            table.insert(gameState.coinsAnimation.fallingCoins, {
                index = coinIndex,
                startY = -UI.Layout.scale(100),  -- Off-screen top
                currentY = -UI.Layout.scale(100),
                targetY = targetY,
                startX = targetX + randomXOffset,
                currentX = targetX + randomXOffset,
                targetX = targetX,
                elapsed = 0,
                startDelay = (i - 1) * 0.08,  -- 80ms stagger per coin
                duration = 0.5,
                settleElapsed = 0,
                settleDuration = 0.25,
                phase = "waiting",  -- "waiting", "falling", "settling", "settled"
                xFlip = love.math.random() > 0.5,
                stackIndex = stackIndex,
                coinInStack = coinInStack
            })
        end

        -- Keep existing popup
        local coinX = UI.Layout.scale(60)
        local coinY = gameState.screen.height - UI.Layout.scale(120)
        UI.Animation.createScorePopup(difference, coinX, coinY, bonusInfo and bonusInfo.hasBonus)

    elseif difference < 0 then
        -- Losing coins - instant update (no animation needed)
        gameState.coins = newCoins
        gameState.coinsAnimation.settledCoins = newCoins
        gameState.coinsAnimation.targetCoins = newCoins

        -- Regenerate flips
        gameState.coinsAnimation.coinFlips = {}
        for i = 1, newCoins do
            gameState.coinsAnimation.coinFlips[i] = love.math.random() > 0.5
        end
    end
end

function updateChipLoopSound()
    -- Check if chip loop should be playing but current sound finished
    if gameState.coinsAnimation.chipLoopActive and
       gameState.coinsAnimation.firstCoinLanded and
       #gameState.coinsAnimation.fallingCoins > 0 then

        -- If current chip loop finished, play next random one
        if not UI.Audio.isChipLoopPlaying() then
            UI.Audio.playChipLoop()
        end
    end
end

function updateFallingCoins(dt)
    if not gameState.coinsAnimation.fallingCoins then return end

    local allSettled = true

    for i = #gameState.coinsAnimation.fallingCoins, 1, -1 do
        local coin = gameState.coinsAnimation.fallingCoins[i]

        if coin.phase == "waiting" then
            coin.elapsed = coin.elapsed + dt
            if coin.elapsed >= coin.startDelay then
                coin.phase = "falling"
                coin.elapsed = 0
            end
            allSettled = false

        elseif coin.phase == "falling" then
            coin.elapsed = coin.elapsed + dt
            local progress = math.min(coin.elapsed / coin.duration, 1.0)

            -- Ease out cubic for falling motion
            local easedProgress = 1 - math.pow(1 - progress, 3)

            -- Update Y position (falling down)
            coin.currentY = coin.startY + (coin.targetY - coin.startY) * easedProgress

            -- Update X position (drift toward target)
            coin.currentX = coin.startX + (coin.targetX - coin.startX) * easedProgress

            -- Start settling phase earlier - when coin is still 15 pixels above target
            local settleStartOffset = 15
            if coin.currentY >= coin.targetY - settleStartOffset then
                coin.phase = "settling"
                coin.settleElapsed = 0
                coin.settleStartY = coin.currentY  -- Remember where settling started
                coin.currentX = coin.targetX

                -- Start chip loop when first coin lands
                if not gameState.coinsAnimation.firstCoinLanded and gameState.coinsAnimation.chipLoopActive then
                    gameState.coinsAnimation.firstCoinLanded = true
                    UI.Audio.playChipLoop()
                end
            end
            allSettled = false

        elseif coin.phase == "settling" then
            coin.settleElapsed = coin.settleElapsed + dt
            local progress = math.min(coin.settleElapsed / coin.settleDuration, 1.0)

            -- Bounce effect using easeOutBack
            local c1 = 1.70158
            local c3 = c1 + 1
            local bounce = 1 + c3 * math.pow(progress - 1, 3) + c1 * math.pow(progress - 1, 2)

            -- Settle from wherever it started settling down to target with bounce
            local settleDistance = (coin.settleStartY or coin.targetY) - coin.targetY
            coin.currentY = coin.targetY + (settleDistance * (1 - progress)) + (10 * (1 - bounce))

            if progress >= 1.0 then
                coin.phase = "settled"
                coin.currentY = coin.targetY

                -- Increment settled count and actual coin count
                gameState.coinsAnimation.settledCoins = gameState.coinsAnimation.settledCoins + 1
                gameState.coins = gameState.coinsAnimation.settledCoins

                -- Store flip state
                gameState.coinsAnimation.coinFlips[coin.index] = coin.xFlip

                -- Remove from falling array
                table.remove(gameState.coinsAnimation.fallingCoins, i)
            end
            allSettled = false
        end
    end

    -- Clean up when all settled
    if allSettled and #gameState.coinsAnimation.fallingCoins == 0 then
        gameState.coinsAnimation.settledCoins = gameState.coinsAnimation.targetCoins
        gameState.coins = gameState.coinsAnimation.targetCoins

        -- Stop chip loop sound abruptly when last coin settles
        if gameState.coinsAnimation.chipLoopActive then
            UI.Audio.stopChipLoop()
            gameState.coinsAnimation.chipLoopActive = false
            gameState.coinsAnimation.firstCoinLanded = false
        end
    end
end

function updateCoinBreakdownAnimation(dt)
    -- Process the queue of breakdown items waiting to animate
    if #gameState.coinBreakdownQueue > 0 then
        local currentItem = gameState.coinBreakdownQueue[1]

        if not currentItem.animationStarted then
            -- Start animating this item
            currentItem.animationStarted = true
            currentItem.elapsed = 0
            currentItem.opacity = 0
            currentItem.yOffset = 20  -- Start slightly below

            -- Add to visible breakdown list
            table.insert(gameState.coinBreakdown, currentItem)

            -- Trigger coin addition animation - use coinsAnimation.targetCoins to track cumulative
            -- This ensures each item adds to the previous target, not the settled amount
            local currentTarget = gameState.coinsAnimation.targetCoins or gameState.coins
            updateCoins(currentTarget + currentItem.coins, {hasBonus = false})
        end

        -- Animate opacity and position
        currentItem.elapsed = currentItem.elapsed + dt
        local progress = math.min(currentItem.elapsed / 0.3, 1.0)  -- 300ms animation

        -- Ease out for smooth appearance
        local easedProgress = 1 - math.pow(1 - progress, 3)
        currentItem.opacity = easedProgress
        currentItem.yOffset = 20 * (1 - easedProgress)

        if progress >= 1.0 then
            currentItem.animated = true
            currentItem.opacity = 1.0
            currentItem.yOffset = 0

            -- Remove from queue
            table.remove(gameState.coinBreakdownQueue, 1)
        end
    end
end

function updateToolStackAnimation(dt)
    if not gameState.toolStackAnimation.isActivated then
        return
    end

    -- Update animation progress
    gameState.toolStackAnimation.animationProgress = gameState.toolStackAnimation.animationProgress + dt * 4  -- 0.25s animation

    local progress = math.min(gameState.toolStackAnimation.animationProgress, 1.0)

    -- Stronger wobble animation for selected/dragging tool
    -- Bounce animation: scale from 1.0 -> 1.15 -> 1.0
    local bounceProgress = progress * 2  -- 0-2 range
    if bounceProgress <= 1.0 then
        -- Growing phase
        gameState.toolStackAnimation.scale = 1.0 + (0.15 * bounceProgress)
    else
        -- Shrinking phase
        gameState.toolStackAnimation.scale = 1.15 - (0.15 * (bounceProgress - 1.0))
    end

    -- Tilt animation: rotate back and forth (±10 degrees)
    local tiltMax = math.rad(10)
    gameState.toolStackAnimation.tiltAngle = math.sin(progress * math.pi * 2) * tiltMax

    -- Animation complete - reset state but keep activated until drag starts
    if progress >= 1.0 then
        -- Reset to neutral state but keep activated flag
        gameState.toolStackAnimation.scale = 1.0
        gameState.toolStackAnimation.tiltAngle = 0
        gameState.toolStackAnimation.animationProgress = 0
    end
end

function updateToolExplosionAnimation(dt)
    local explosion = gameState.toolStackExplosion

    if explosion.isCollapsing then
        -- Collapse animation (back to stacked)
        explosion.explosionProgress = explosion.explosionProgress - dt * 4  -- 0.25s collapse

        if explosion.explosionProgress <= 0 then
            explosion.explosionProgress = 0
            explosion.isExploded = false
            explosion.isCollapsing = false
            explosion.idleAnimations = {}
        end
    elseif explosion.isExploded and explosion.explosionProgress < 1.0 then
        -- Explosion animation (spreading out)
        explosion.explosionProgress = explosion.explosionProgress + dt * 3.33  -- 0.3s explosion
        explosion.explosionProgress = math.min(explosion.explosionProgress, 1.0)
    end
end

function updateToolIdleAnimations(dt)
    local explosion = gameState.toolStackExplosion

    -- Only animate idle when exploded
    if not explosion.isExploded or explosion.explosionProgress < 1.0 then
        return
    end

    local ownedTools = gameState.ownedTools or {}
    local time = love.timer.getTime()

    for i, toolId in ipairs(ownedTools) do
        -- Initialize idle animation state for this tool if needed
        if not explosion.idleAnimations[i] then
            explosion.idleAnimations[i] = {
                phase = math.random() * math.pi * 2,  -- Random start phase for variety
                floatOffset = 0,
                tiltAngle = 0
            }
        end

        local anim = explosion.idleAnimations[i]

        -- Subtle float animation (2-3px amplitude, 2-3s period)
        local floatPeriod = 2.5 + (i * 0.3)  -- Stagger periods slightly
        local floatPhase = (time / floatPeriod) + anim.phase
        anim.floatOffset = math.sin(floatPhase * math.pi * 2) * 2.5

        -- Subtle tilt animation (±3 degrees, slower rotation)
        local tiltPeriod = 3.0 + (i * 0.2)
        local tiltPhase = (time / tiltPeriod) + anim.phase
        anim.tiltAngle = math.sin(tiltPhase * math.pi * 2) * math.rad(3)
    end
end

function startScoringSequence(tiles)
    gameState.scoringSequence = {
        tiles = tiles,
        currentTileIndex = 1,
        accumulatedValue = 0,
        showingMultiplier = false,
        showingFinal = false,
        phase = "scoring_tiles",  -- "scoring_tiles", "multiplying", "final", "transferring"
        timer = 0,
        tileAnimDelay = 0.4,
        finalTileAnimating = false,
        waitingForFinalTile = false
    }

    -- Initialize formula display at 0
    gameState.formulaDisplayValue = 0
    gameState.formulaTargetValue = 0
    gameState.formulaCountSpeed = 0
    gameState.formulaAnimation = {
        scale = 1.0,
        shake = 0,
        opacity = 1.0,
        yOffset = 0,
        color = {UI.Colors.FONT_WHITE[1], UI.Colors.FONT_WHITE[2], UI.Colors.FONT_WHITE[3], 1}  -- White for summing phase
    }

    -- Sort tiles from left to right for visual consistency
    table.sort(gameState.scoringSequence.tiles, function(a, b)
        return a.x < b.x
    end)
end

function updateScoringSequence(dt)
    if not gameState.scoringSequence then return end
    
    local seq = gameState.scoringSequence
    seq.timer = seq.timer + dt
    
    if seq.phase == "scoring_tiles" then
        -- Check if we're waiting for final tile to finish
        if seq.waitingForFinalTile and not seq.finalTileAnimating then
            -- Final tile finished, move to multiplier phase
            seq.phase = "multiplying"
            seq.showingMultiplier = true
            seq.timer = 0
            seq.waitingForFinalTile = false
        else
            -- Check if it's time to animate the next tile
            local tileDelay = (seq.currentTileIndex - 1) * seq.tileAnimDelay
            
            if seq.timer >= tileDelay then
                if seq.currentTileIndex <= #seq.tiles then
                    local tile = seq.tiles[seq.currentTileIndex]
                    
                    -- Add this tile's value to accumulated
                    local tileValue = Domino.getValue(tile)
                    local isDouble = Domino.isDouble(tile)
                    local addedValue = tileValue + (isDouble and 10 or 0)
                    seq.accumulatedValue = seq.accumulatedValue + addedValue

                    -- Set formula target and trigger counting animation
                    gameState.formulaTargetValue = seq.accumulatedValue
                    gameState.formulaCountSpeed = math.max(100, addedValue * 3)  -- Speed based on added value

                    -- Animate the tile with shake effect
                    animateTileScoring(tile)
                    
                    seq.currentTileIndex = seq.currentTileIndex + 1
                else
                    -- All tiles have been triggered, wait for final tile to finish animating
                    seq.waitingForFinalTile = true
                end
            end
        end
    elseif seq.phase == "multiplying" then
        -- Wait for formula to reach accumulated value, then show multiplier
        if gameState.formulaDisplayValue >= seq.accumulatedValue - 1 then
            -- Show multiplier and calculate final score
            local breakdown = Scoring.getScoreBreakdown(seq.tiles)
            local finalScore = breakdown.total

            -- Animate to final multiplied value
            gameState.formulaTargetValue = finalScore
            gameState.formulaCountSpeed = math.max(150, (finalScore - seq.accumulatedValue) * 2)

            -- Change color to pink for multiplication
            gameState.formulaAnimation.color = {UI.Colors.FONT_PINK[1], UI.Colors.FONT_PINK[2], UI.Colors.FONT_PINK[3], 1}

            seq.phase = "final"
            seq.showingFinal = true
            seq.timer = 0
        end
    elseif seq.phase == "final" then
        -- Wait for formula to reach final value, then transfer
        local breakdown = Scoring.getScoreBreakdown(seq.tiles)
        if gameState.formulaDisplayValue >= breakdown.total - 1 then
            -- Brief wait before transferring
            if seq.timer >= 0.2 then
                seq.phase = "transferring"
                seq.timer = 0

                -- Start transfer animation: move formula up and fade out (faster)
                UI.Animation.animateTo(gameState.formulaAnimation, {yOffset = -50, opacity = 0}, 0.5, "easeOutQuart", function()
                    -- Transfer complete, update score
                    completeScoringSequence()
                end)

                -- Change color to black (outline) for transfer
                gameState.formulaAnimation.color = {UI.Colors.OUTLINE[1], UI.Colors.OUTLINE[2], UI.Colors.OUTLINE[3], 1}
            end
        end
    elseif seq.phase == "transferring" then
        -- Just wait for animation to complete (handled by callback)
    end
end

function animateTileScoring(tile)
    -- Create satisfying punch-out shake effect
    tile.scoreScale = tile.scoreScale or 1.0
    tile.scoreShake = tile.scoreShake or 0

    -- Play tile sound for audio feedback
    UI.Audio.playTilePlaced()

    local seq = gameState.scoringSequence
    local isFinalTile = (seq.currentTileIndex == #seq.tiles)
    
    if isFinalTile then
        seq.finalTileAnimating = true
    end
    
    UI.Animation.animateTo(tile, {scoreScale = 1.15}, 0.15, "easeOutBack", function()
        UI.Animation.animateTo(tile, {scoreScale = 1.0}, 0.25, "easeOutBack", function()
            -- If this was the final tile, mark that it's done animating
            if isFinalTile then
                seq.finalTileAnimating = false
            end
        end)
    end)
    
    -- Add shake effect
    tile.scoreShake = 5
    UI.Animation.animateTo(tile, {scoreShake = 0}, 0.3, "easeOutQuart")
    
    -- Animate the formula counter as well
    seq.formulaAnimation = seq.formulaAnimation or {scale = 1.0, shake = 0}
    seq.formulaAnimation.scale = 1.0
    seq.formulaAnimation.shake = 3
    
    UI.Animation.animateTo(seq.formulaAnimation, {scale = 1.2}, 0.1, "easeOutBack", function()
        UI.Animation.animateTo(seq.formulaAnimation, {scale = 1.0}, 0.2, "easeOutBack")
    end)
    UI.Animation.animateTo(seq.formulaAnimation, {shake = 0}, 0.3, "easeOutQuart")
end

function completeScoringSequence()
    local tiles = gameState.scoringSequence.tiles
    local score = Scoring.calculateScore(tiles)
    local breakdown = Scoring.getScoreBreakdown(tiles)
    
    -- Add celebration text for successful plays
    local centerX = gameState.screen.width / 2
    local centerY = gameState.screen.height / 2
    local hasBonus = breakdown.multiplier > 1 or breakdown.doubleBonus > 0
    
    if hasBonus then
        UI.Animation.createFloatingText("NICE COMBO!", centerX, centerY, {
            color = {UI.Colors.FONT_PINK[1], UI.Colors.FONT_PINK[2], UI.Colors.FONT_PINK[3], 1},
            fontSize = "large",
            duration = 2.5,
            riseDistance = 100,
            startScale = 0.3,
            endScale = 1.8,
            bounce = true,
            easing = "easeOutElastic"
        })
    elseif #tiles >= 3 then
        UI.Animation.createFloatingText("GOOD PLAY!", centerX, centerY, {
            color = {0.2, 0.9, 0.3, 1},
            fontSize = "medium",
            duration = 2.0,
            riseDistance = 80,
            startScale = 0.5,
            endScale = 1.4,
            bounce = true,
            easing = "easeOutBack"
        })
    end
    
    -- Update the actual game score
    updateScore(gameState.score + score, {hasBonus = hasBonus})
    
    -- Clear scoring sequence state
    gameState.scoringSequence = nil
    
    -- Continue with normal game flow (refill hand, etc.)
    gameState.handsPlayed = gameState.handsPlayed + 1

    -- Call challenge hand complete handlers
    if Challenges then
        Challenges.onHandComplete(gameState)
    end

    -- Remove tiles from hand and placed tiles
    -- First mark the tiles as selected so they can be removed
    for _, placedTile in ipairs(tiles) do
        for _, handTile in ipairs(gameState.hand) do
            if handTile.id == placedTile.id then
                handTile.selected = true
                break
            end
        end
    end

    Hand.removeSelectedTiles(gameState.hand)

    -- Clear placed tiles but preserve anchor tile if it exists
    local anchorTile = Challenges and Challenges.getAnchorTile(gameState)
    gameState.placedTiles = {}

    if anchorTile then
        -- Re-add anchor tile to placed tiles so it persists
        table.insert(gameState.placedTiles, anchorTile)
        -- Re-position anchor tile at center
        Board.arrangePlacedTiles()
    end

    -- Check game end condition BEFORE refilling hand
    -- This way we can animate the actual remaining tiles, not a refilled hand
    local isGameEnding = gameState.score >= gameState.targetScore or gameState.handsPlayed >= gameState.maxHandsPerRound

    if not isGameEnding then
        -- Only refill hand if game is continuing
        local drawnCount, drawnTiles = Hand.refillHand(gameState.hand, gameState.deck, 7)

        -- Animate ONLY the newly drawn tiles from right (not the entire hand)
        if drawnTiles and #drawnTiles > 0 then
            Hand.animateTilesDraw(gameState.hand, 0, drawnTiles)
        end
    else
        -- Game is ending - check if it's a loss (maxed out hands)
        -- For wins, wait for score countdown to complete (handled in updateScoreCountdown)
        if gameState.handsPlayed >= gameState.maxHandsPerRound and not gameState.winSequenceTriggered then
            gameState.winSequenceTriggered = true
            Touch.checkGameEnd()
        end
    end
end

function animateButtonPress(buttonName)
    if gameState.buttonAnimations and gameState.buttonAnimations[buttonName] then
        local button = gameState.buttonAnimations[buttonName]
        button.pressed = true
        
        UI.Animation.animateTo(button, {scale = 0.9}, 0.1, "easeOutQuart", function()
            UI.Animation.animateTo(button, {scale = 1.1}, 0.15, "easeOutBack", function()
                UI.Animation.animateTo(button, {scale = 1.0}, 0.2, "easeOutQuart", function()
                    button.pressed = false
                end)
            end)
        end)
    end
end

-- Update candle light animation (cycle through frames at 12 fps)
function updateCandleLightAnimation(dt)
    if not candleLightFrames or #candleLightFrames == 0 then
        return
    end

    candleLightAnimationTime = candleLightAnimationTime + dt

    -- Check if we need to advance to the next frame
    if candleLightAnimationTime >= candleLightFrameDuration then
        candleLightAnimationTime = candleLightAnimationTime - candleLightFrameDuration
        candleLightFrameIndex = candleLightFrameIndex + 1

        -- Loop back to first frame
        if candleLightFrameIndex > #candleLightFrames then
            candleLightFrameIndex = 1
        end
    end
end

function love.update(dt)
    Touch.update(dt)
    UI.Animation.update(dt)
    UI.Animation.updateShadowFlicker(dt)
    UI.Animation.updateDiePhysics(dt)
    UI.Animation.updateCupAnimations(dt)
    UI.Renderer.updateEyeBlinks(dt)
    updateFallingCoins(dt)
    updateCoinBreakdownAnimation(dt)
    updateChipLoopSound()
    updateToolStackAnimation(dt)
    updateToolExplosionAnimation(dt)
    updateToolIdleAnimations(dt)
    updateCandleLightAnimation(dt)
    UI.Audio.updateMapTextures(dt)

    if gameState.gamePhase == "title_screen" then
        UI.TitleScreen.updateTitleTileAnimations(dt)
        -- Stop map ambiance on title screen
        if UI.Audio.isMapAmbiancePlaying() then
            UI.Audio.stopMapAmbiance()
        end
    elseif gameState.gamePhase == "playing" or gameState.gamePhase == "won" then
        -- Keep updating score countdown and idle animation even in "won" phase to let it finish
        updateScoreCountdown(dt)
        updateScoreIdleAnimation(dt)
        updateVictoryBellSequence(dt)

        -- Stop map ambiance during combat
        if UI.Audio.isMapAmbiancePlaying() then
            UI.Audio.stopMapAmbiance()
        end

        if gameState.gamePhase == "playing" then
            Hand.update(dt)
            Board.update(dt)
            updateScoringSequence(dt)
            updateFormulaCountAnimation(dt)
        end
    elseif gameState.gamePhase == "tiles_menu" or gameState.gamePhase == "artifacts_menu" or gameState.gamePhase == "contracts_menu" then
        -- Dampen map ambiance when inside node menus
        if UI.Audio.isMapAmbiancePlaying() then
            UI.Audio.dampenMapAmbiance()
        end

        if gameState.gamePhase == "tiles_menu" then
            local isFusionMode = (gameState.currentTilesNodeType == "alchemy")
            if isFusionMode then
                -- Update fusion hand using regular Hand.update logic
                if gameState.fusionHand then
                    Hand.updatePositions(gameState.fusionHand)
                    Hand.updateIdleAnimations(gameState.fusionHand, dt)
                end
            else
                -- Update shop hand tiles with all animations (like combat hand)
                if gameState.offeredTiles then
                    Hand.updatePositions(gameState.offeredTiles, true)  -- Skip sorting
                    Hand.updateDrawAnimations(gameState.offeredTiles, dt)  -- Draw animation (tiles sliding in from right)
                    Hand.updateDiscardAnimations(gameState.offeredTiles, dt)  -- Discard animation (tiles falling down)
                    Hand.updateIdleAnimations(gameState.offeredTiles, dt)  -- Idle floating/rotation
                end
            end
        elseif gameState.gamePhase == "artifacts_menu" then
            -- Update tool sprite animations (similar to tile shop)
            if gameState.offeredTools then
                -- Update positions for all tool sprites
                for i, tool in ipairs(gameState.offeredTools) do
                    local x, y = UI.Layout.getHandPosition(i - 1, #gameState.offeredTools)
                    if not tool.isDragging and not tool.isAnimating then
                        tool.visualX = x
                        tool.visualY = y
                    end
                    tool.x = x
                    tool.y = y
                end

                -- Animate draw, idle animations
                updateToolSpriteDrawAnimations(gameState.offeredTools, dt)
                updateToolSpriteIdleAnimations(gameState.offeredTools, dt)
            end
        end
    elseif gameState.gamePhase == "map" then
        -- Start map ambiance when entering map phase
        if not UI.Audio.isMapAmbiancePlaying() then
            UI.Audio.startMapAmbiance()
        else
            -- Restore ambiance if it was dampened
            UI.Audio.restoreMapAmbiance()
        end

        -- Update map path preview sounds
        if gameState.currentMap then
            Map.updatePathSounds(gameState.currentMap)
        end
    elseif gameState.gamePhase == "node_confirmation" then
        -- Dampen map ambiance when in node confirmation dialog
        if UI.Audio.isMapAmbiancePlaying() then
            UI.Audio.dampenMapAmbiance()
        end

        -- Update map path preview sounds
        if gameState.currentMap then
            Map.updatePathSounds(gameState.currentMap)
        end
    elseif gameState.gamePhase == "lost" then
        -- Stop map ambiance on lost screen
        if UI.Audio.isMapAmbiancePlaying() then
            UI.Audio.stopMapAmbiance()
        end
    end
end

function love.draw()
    -- PASS 1: Render entire game to canvas
    love.graphics.setCanvas(mainCanvas)
    -- Don't clear here - let each screen phase handle its own background properly
    
    UI.Layout.begin()
    
    -- Each phase draws its own background as before
    if gameState.gamePhase == "title_screen" then
        UI.TitleScreen.draw()
        UI.Renderer.drawSettingsMenu()
    elseif gameState.gamePhase == "playing" or gameState.gamePhase == "won" then
        UI.Renderer.drawBackground()
        UI.Renderer.drawBoard(gameState.board)
        UI.Renderer.drawPlacedTiles()
        UI.Animation.drawDiePhysics()  -- Draw flying/settling dice
        UI.Renderer.drawActiveDieSprites()  -- Draw settled dice on board
        UI.Renderer.drawHand(gameState.hand)
        UI.Renderer.drawToolButtons()  -- Draw tool buttons
        UI.Renderer.drawScore(gameState.score)
        UI.Renderer.drawUI()
        UI.Renderer.drawCoinSprites()  -- Draw coin sprites first
        UI.Renderer.drawCoinText()  -- Draw coin text on top
        UI.Renderer.drawVictoryPhrase()  -- Draw victory phrase in center
        UI.Renderer.drawSettingsButton()
        UI.Renderer.drawSettingsMenu()
        -- Draw game over overlay for won state (button only, no full overlay)
        if gameState.gamePhase == "won" then
            UI.Renderer.drawGameOver()
        end
    elseif gameState.gamePhase == "map" then
        UI.Renderer.drawMap()
        UI.Renderer.drawSettingsButton()
        UI.Renderer.drawSettingsMenu()
    elseif gameState.gamePhase == "node_confirmation" then
        UI.Renderer.drawMap()  -- Draw map background
        UI.Renderer.drawNodeConfirmation()  -- Draw confirmation dialog on top
        UI.Renderer.drawSettingsButton()
        UI.Renderer.drawSettingsMenu()
    elseif gameState.gamePhase == "tiles_menu" then
        UI.Renderer.drawTilesMenu()
        UI.Renderer.drawSettingsButton()
        UI.Renderer.drawSettingsMenu()
    elseif gameState.gamePhase == "artifacts_menu" then
        UI.Renderer.drawArtifactsMenu()
        UI.Renderer.drawSettingsButton()
        UI.Renderer.drawSettingsMenu()
    elseif gameState.gamePhase == "contracts_menu" then
        UI.Renderer.drawContractsMenu()
        UI.Renderer.drawSettingsButton()
        UI.Renderer.drawSettingsMenu()
    elseif gameState.gamePhase == "lost" then
        UI.Renderer.drawGameOver()
    end
    
    UI.Animation.drawFloatingTexts()
    
    UI.Layout.finish()
    
    -- PASS 2: Apply CRT shader and render canvas to screen
    love.graphics.setCanvas()  -- Reset to screen
    
    -- Ensure proper color and blend state before applying shader
    love.graphics.setColor(1, 1, 1, 1)
    love.graphics.setBlendMode("alpha")
    love.graphics.setShader(crtShader)
    
    -- Set shader uniforms
    crtShader:send("time", love.timer.getTime())
    crtShader:send("resolution", {gameState.screen.width, gameState.screen.height})
    
    -- Draw the canvas to screen through CRT shader
    love.graphics.draw(mainCanvas, 0, 0)
    
    -- Reset shader and state
    love.graphics.setShader()
    love.graphics.setColor(1, 1, 1, 1)
end

function love.resize(w, h)
    gameState.screen.width = w
    gameState.screen.height = h
    gameState.screen.scale = math.min(w / 800, h / 600)
    
    -- Recreate canvas with new dimensions for CRT shader
    if mainCanvas then
        mainCanvas:release()
    end
    mainCanvas = love.graphics.newCanvas(w, h, {format = "rgba8", readable = true, msaa = 0})
    
    UI.Fonts.recalculate()
    
    -- Force layout recalculation for orientation changes
    UI.Layout.recalculate()
    
    -- Update hand positions for responsive layout
    if gameState.hand then
        Hand.updatePositions(gameState.hand)
    end
    
    -- Rearrange board tiles for new screen dimensions
    if gameState.placedTiles and #gameState.placedTiles > 0 then
        Board.arrangePlacedTiles()
    end
end

function love.mousepressed(x, y, button, istouch)
    if istouch or button == 1 then
        Touch.pressed(x, y, istouch)
    end
end

function love.mousereleased(x, y, button, istouch)
    if istouch or button == 1 then
        Touch.released(x, y, istouch)
    end
end

function love.mousemoved(x, y, dx, dy, istouch)
    Touch.moved(x, y, dx, dy, istouch)
end

function love.touchpressed(id, x, y, dx, dy, pressure)
    Touch.pressed(x, y, true, id)
end

function love.touchreleased(id, x, y, dx, dy, pressure)
    Touch.released(x, y, true, id)
end

function love.touchmoved(id, x, y, dx, dy, pressure)
    Touch.moved(x, y, dx, dy, true, id)
end

function loadDominoSprites()
    dominoSprites = {}
    dominoTiltedSprites = {}

    -- Load vertical sprites (for hand tiles)
    for i = 0, 9 do
        for j = i, 9 do
            local filename = "sprites/tiles/" .. i .. j .. ".png"
            if love.filesystem.getInfo(filename) then
                local sprite = love.graphics.newImage(filename)
                dominoSprites[i .. j] = sprite
            end
        end
    end

    -- Load special vertical sprites (odd/even tiles)
    -- Number-even combinations (all numbers 0-9 can have "even" side)
    for i = 0, 9 do
        local filename = "sprites/tiles/" .. i .. "even.png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            dominoSprites[i .. "even"] = sprite
        end
    end

    -- Number-odd combinations (all numbers 0-9 can have "odd" side)
    for i = 0, 9 do
        local filename = "sprites/tiles/" .. i .. "odd.png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            dominoSprites[i .. "odd"] = sprite
        end
    end

    -- Special-special combinations
    local specialCombos = {"oddodd", "eveneven", "oddeven"}
    for _, combo in ipairs(specialCombos) do
        local filename = "sprites/tiles/" .. combo .. ".png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            dominoSprites[combo] = sprite
        end
    end

    -- Load X-variant vertical sprites (for values 10+)
    -- Number-X combinations (1-9 with "x" for values >= 10)
    for i = 1, 9 do
        local filename = "sprites/tiles/" .. i .. "x.png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            dominoSprites[i .. "x"] = sprite
        end
    end

    -- X-X combination (for double values >= 10)
    local xxFilename = "sprites/tiles/xx.png"
    if love.filesystem.getInfo(xxFilename) then
        local sprite = love.graphics.newImage(xxFilename)
        dominoSprites["xx"] = sprite
    end

    -- Special-X combinations (odd/even with X)
    local xFilename = "sprites/tiles/oddx.png"
    if love.filesystem.getInfo(xFilename) then
        local sprite = love.graphics.newImage(xFilename)
        dominoSprites["oddx"] = sprite
    end
    xFilename = "sprites/tiles/evenx.png"
    if love.filesystem.getInfo(xFilename) then
        local sprite = love.graphics.newImage(xFilename)
        dominoSprites["evenx"] = sprite
    end

    -- Load tilted sprites (for board tiles) - note: folder was titled_tiles, likely meant to be tilted_tiles
    local rawTiltedSprites = {}
    -- Load tiles 0-6 with "t" suffix
    for i = 0, 6 do
        for j = i, 6 do
            local filename = "sprites/titled_tiles/" .. i .. j .. "t.png"
            if love.filesystem.getInfo(filename) then
                local sprite = love.graphics.newImage(filename)
                rawTiltedSprites[i .. j] = sprite
            end
        end
    end

    -- Load tiles 7-9 WITHOUT "t" suffix
    for i = 0, 9 do
        for j = math.max(i, 7), 9 do
            local filename = "sprites/titled_tiles/" .. i .. j .. ".png"
            if love.filesystem.getInfo(filename) then
                local sprite = love.graphics.newImage(filename)
                rawTiltedSprites[i .. j] = sprite
            end
        end
    end

    -- Load special tilted sprites (odd/even tiles)
    -- Number-even combinations (all numbers 0-9 can have "even" side)
    for i = 0, 9 do
        local filename = "sprites/titled_tiles/" .. i .. "even.png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            rawTiltedSprites[i .. "even"] = sprite
        end
    end

    -- Number-odd combinations (all numbers 0-9 can have "odd" side)
    for i = 0, 9 do
        local filename = "sprites/titled_tiles/" .. i .. "odd.png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            rawTiltedSprites[i .. "odd"] = sprite
        end
    end

    -- Special-special combinations
    for _, combo in ipairs(specialCombos) do
        local filename = "sprites/titled_tiles/" .. combo .. ".png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            rawTiltedSprites[combo] = sprite
        end
    end

    -- Load X-variant tilted sprites (for values 10+)
    -- Number-X combinations (1-9 with "x" for values >= 10)
    for i = 1, 9 do
        local filename = "sprites/titled_tiles/" .. i .. "x.png"
        if love.filesystem.getInfo(filename) then
            local sprite = love.graphics.newImage(filename)
            rawTiltedSprites[i .. "x"] = sprite
        end
    end

    -- X-X combination (for double values >= 10)
    local xxTiltedFilename = "sprites/titled_tiles/xx.png"
    if love.filesystem.getInfo(xxTiltedFilename) then
        local sprite = love.graphics.newImage(xxTiltedFilename)
        rawTiltedSprites["xx"] = sprite
    end

    -- Special-X combinations (odd/even with X)
    local oddxTiltedFilename = "sprites/titled_tiles/oddx.png"
    if love.filesystem.getInfo(oddxTiltedFilename) then
        local sprite = love.graphics.newImage(oddxTiltedFilename)
        rawTiltedSprites["oddx"] = sprite
    end
    local evenxTiltedFilename = "sprites/titled_tiles/evenx.png"
    if love.filesystem.getInfo(evenxTiltedFilename) then
        local sprite = love.graphics.newImage(evenxTiltedFilename)
        rawTiltedSprites["evenx"] = sprite
    end
    
    -- Create mapping for all possible domino combinations (vertical sprites)
    for i = 0, 9 do
        for j = 0, 9 do
            local key = i .. j
            if not dominoSprites[key] then
                -- Try inverted version (j-i instead of i-j)
                local invertedKey = j .. i
                if dominoSprites[invertedKey] then
                    -- Mark this sprite as needing 180-degree rotation
                    dominoSprites[key] = {
                        sprite = dominoSprites[invertedKey],
                        inverted = true
                    }
                end
            elseif dominoSprites[key] then
                -- Wrap existing sprites in consistent format
                local existingSprite = dominoSprites[key]
                dominoSprites[key] = {
                    sprite = existingSprite,
                    inverted = false
                }
            end
        end
    end

    -- Create mapping for all tilted sprite combinations
    for i = 0, 9 do
        for j = 0, 9 do
            local key = i .. j
            local minVal = math.min(i, j)
            local maxVal = math.max(i, j)
            local spriteKey = minVal .. maxVal

            -- Check if we have the base sprite (e.g., "14" for both "14" and "41")
            local baseSprite = rawTiltedSprites[spriteKey]
            if baseSprite then
                -- Create entries for both orientations
                dominoTiltedSprites[spriteKey] = {
                    sprite = baseSprite,
                    flipped = false  -- Normal orientation (smaller number left)
                }

                -- If it's not a double, create the flipped version
                if minVal ~= maxVal then
                    local flippedKey = maxVal .. minVal
                    dominoTiltedSprites[flippedKey] = {
                        sprite = baseSprite,
                        flipped = true  -- Flipped orientation (larger number left)
                    }
                end
            end
        end
    end

    -- Wrap special vertical sprites in consistent format
    -- Number-even combinations (all numbers 0-9)
    for i = 0, 9 do
        local key = i .. "even"
        if dominoSprites[key] then
            local existingSprite = dominoSprites[key]
            dominoSprites[key] = {
                sprite = existingSprite,
                inverted = false
            }
        end
        -- Create reverse mapping (even-number)
        local reverseKey = "even" .. i
        if dominoSprites[key] and dominoSprites[key].sprite then
            dominoSprites[reverseKey] = {
                sprite = dominoSprites[key].sprite,
                inverted = true
            }
        end
    end

    -- Number-odd combinations (all numbers 0-9)
    for i = 0, 9 do
        local key = i .. "odd"
        if dominoSprites[key] then
            local existingSprite = dominoSprites[key]
            dominoSprites[key] = {
                sprite = existingSprite,
                inverted = false
            }
        end
        -- Create reverse mapping (odd-number)
        local reverseKey = "odd" .. i
        if dominoSprites[key] and dominoSprites[key].sprite then
            dominoSprites[reverseKey] = {
                sprite = dominoSprites[key].sprite,
                inverted = true
            }
        end
    end

    -- Wrap X-variant vertical sprites in consistent format
    -- Number-X combinations (1-9 with "x")
    for i = 1, 9 do
        local key = i .. "x"
        if dominoSprites[key] then
            local existingSprite = dominoSprites[key]
            dominoSprites[key] = {
                sprite = existingSprite,
                inverted = false
            }
        end
        -- Create reverse mapping (x-number)
        local reverseKey = "x" .. i
        if dominoSprites[key] and dominoSprites[key].sprite then
            dominoSprites[reverseKey] = {
                sprite = dominoSprites[key].sprite,
                inverted = true
            }
        end
    end

    -- Wrap xx sprite
    if dominoSprites["xx"] then
        local existingSprite = dominoSprites["xx"]
        dominoSprites["xx"] = {
            sprite = existingSprite,
            inverted = false
        }
    end

    -- Wrap special-x vertical sprites
    if dominoSprites["oddx"] then
        local existingSprite = dominoSprites["oddx"]
        dominoSprites["oddx"] = {
            sprite = existingSprite,
            inverted = false
        }
        -- Create reverse mapping (x-odd)
        dominoSprites["xodd"] = {
            sprite = existingSprite,
            inverted = true
        }
    end
    if dominoSprites["evenx"] then
        local existingSprite = dominoSprites["evenx"]
        dominoSprites["evenx"] = {
            sprite = existingSprite,
            inverted = false
        }
        -- Create reverse mapping (x-even)
        dominoSprites["xeven"] = {
            sprite = existingSprite,
            inverted = true
        }
    end

    -- Wrap special-special vertical sprites
    for _, combo in ipairs(specialCombos) do
        if dominoSprites[combo] then
            local existingSprite = dominoSprites[combo]
            dominoSprites[combo] = {
                sprite = existingSprite,
                inverted = false
            }
        end
    end

    -- Handle evenodd reverse for oddeven
    if dominoSprites["oddeven"] and dominoSprites["oddeven"].sprite then
        dominoSprites["evenodd"] = {
            sprite = dominoSprites["oddeven"].sprite,
            inverted = true
        }
    end

    -- Wrap special tilted sprites in consistent format
    -- Number-even combinations (all numbers 0-9)
    for i = 0, 9 do
        local key = i .. "even"
        if rawTiltedSprites[key] then
            dominoTiltedSprites[key] = {
                sprite = rawTiltedSprites[key],
                flipped = false
            }
            -- Create reverse mapping
            local reverseKey = "even" .. i
            dominoTiltedSprites[reverseKey] = {
                sprite = rawTiltedSprites[key],
                flipped = true
            }
        end
    end

    -- Number-odd combinations (all numbers 0-9)
    for i = 0, 9 do
        local key = i .. "odd"
        if rawTiltedSprites[key] then
            dominoTiltedSprites[key] = {
                sprite = rawTiltedSprites[key],
                flipped = false
            }
            -- Create reverse mapping
            local reverseKey = "odd" .. i
            dominoTiltedSprites[reverseKey] = {
                sprite = rawTiltedSprites[key],
                flipped = true
            }
        end
    end

    -- Wrap X-variant tilted sprites in consistent format
    -- Number-X combinations (1-9 with "x")
    for i = 1, 9 do
        local key = i .. "x"
        if rawTiltedSprites[key] then
            dominoTiltedSprites[key] = {
                sprite = rawTiltedSprites[key],
                flipped = false
            }
            -- Create reverse mapping (x-number)
            local reverseKey = "x" .. i
            dominoTiltedSprites[reverseKey] = {
                sprite = rawTiltedSprites[key],
                flipped = true
            }
        end
    end

    -- Wrap xx tilted sprite
    if rawTiltedSprites["xx"] then
        dominoTiltedSprites["xx"] = {
            sprite = rawTiltedSprites["xx"],
            flipped = false
        }
    end

    -- Wrap special-x tilted sprites
    if rawTiltedSprites["oddx"] then
        dominoTiltedSprites["oddx"] = {
            sprite = rawTiltedSprites["oddx"],
            flipped = false
        }
        -- Create reverse mapping (x-odd)
        dominoTiltedSprites["xodd"] = {
            sprite = rawTiltedSprites["oddx"],
            flipped = true
        }
    end
    if rawTiltedSprites["evenx"] then
        dominoTiltedSprites["evenx"] = {
            sprite = rawTiltedSprites["evenx"],
            flipped = false
        }
        -- Create reverse mapping (x-even)
        dominoTiltedSprites["xeven"] = {
            sprite = rawTiltedSprites["evenx"],
            flipped = true
        }
    end

    -- Wrap special-special tilted sprites
    for _, combo in ipairs(specialCombos) do
        if rawTiltedSprites[combo] then
            dominoTiltedSprites[combo] = {
                sprite = rawTiltedSprites[combo],
                flipped = false
            }
        end
    end

    -- Handle evenodd reverse for oddeven
    if rawTiltedSprites["oddeven"] then
        dominoTiltedSprites["evenodd"] = {
            sprite = rawTiltedSprites["oddeven"],
            flipped = true
        }
    end
end

function loadDemonTileSprites()
    demonTileSprites = {}

    -- Load base demon tile sprites
    local tiltedFilename = "sprites/demon_tiles/tilted_demon_tile.png"
    if love.filesystem.getInfo(tiltedFilename) then
        demonTileSprites.tilted = love.graphics.newImage(tiltedFilename)
    end

    local verticalFilename = "sprites/demon_tiles/vertical_demon_tile.png"
    if love.filesystem.getInfo(verticalFilename) then
        demonTileSprites.vertical = love.graphics.newImage(verticalFilename)
    end

    -- Load eye animation frames
    demonTileSprites.eyeFrames = {}
    local eyeFiles = {"base.png", "blink1.png", "blink2.png", "blink3.png"}

    for i, filename in ipairs(eyeFiles) do
        local fullPath = "sprites/demon_tiles/eye_animation/" .. filename
        if love.filesystem.getInfo(fullPath) then
            table.insert(demonTileSprites.eyeFrames, love.graphics.newImage(fullPath))
        end
    end

    -- Also keep reference to base eye for backwards compatibility
    if #demonTileSprites.eyeFrames > 0 then
        demonTileSprites.eye = demonTileSprites.eyeFrames[1]
    end
end

function loadTitleScreenSprites()
    titleScreenSprites = {}

    -- Load title tile sprite
    local titleTileFilename = "sprites/title_tile.png"
    if love.filesystem.getInfo(titleTileFilename) then
        titleScreenSprites.titleTile = love.graphics.newImage(titleTileFilename)
    end

    -- Load big eye animation frames
    titleScreenSprites.bigEyeFrames = {}
    local eyeFiles = {"base.png", "blink1.png", "blink2.png", "blink3.png"}

    for i, filename in ipairs(eyeFiles) do
        local fullPath = "sprites/demon_tiles/big_eye_animation/" .. filename
        if love.filesystem.getInfo(fullPath) then
            table.insert(titleScreenSprites.bigEyeFrames, love.graphics.newImage(fullPath))
        end
    end
end

function loadNodeSprites()
    nodeSprites = {}
    
    -- Define node type to sprite mapping
    local nodeTypeMapping = {
        combat = "combat",
        tiles = "tile",      -- Legacy node type (backward compatibility)
        trade = "tile",      -- TRADE nodes use tile sprite
        alchemy = "tile",    -- ALCHEMY nodes use tile sprite
        artifacts = "artifact",
        contracts = "contract",
        start = "tile",      -- Fallback to tile sprite
        boss = "combat"      -- Fallback to combat sprite
    }
    
    -- Load base sprites and selected sprites for each node type
    for nodeType, spriteName in pairs(nodeTypeMapping) do
        -- Load base sprite
        local baseFilename = "sprites/nodes/" .. spriteName .. ".png"
        if love.filesystem.getInfo(baseFilename) then
            local baseSprite = love.graphics.newImage(baseFilename)
            
            -- Load selected sprite
            local selectedFilename = "sprites/nodes/" .. spriteName .. "_selected.png"
            local selectedSprite = nil
            if love.filesystem.getInfo(selectedFilename) then
                selectedSprite = love.graphics.newImage(selectedFilename)
            end
            
            nodeSprites[nodeType] = {
                base = baseSprite,
                selected = selectedSprite
            }
        end
    end
end

function loadCoinSprite()
    local coinFilename = "sprites/currency/coin.png"
    if love.filesystem.getInfo(coinFilename) then
        coinSprite = love.graphics.newImage(coinFilename)
    end
end

function loadCandleSprites()
    -- Load 3 different candle base sprites for variety
    candleSprites = {}
    for i = 1, 3 do
        local candleFilename = "sprites/map/candle" .. i .. ".png"
        if love.filesystem.getInfo(candleFilename) then
            local sprite = love.graphics.newImage(candleFilename)
            sprite:setFilter("nearest", "nearest")  -- Pixel art filtering
            table.insert(candleSprites, sprite)
        end
    end

    -- Load animated candle light frames (4 frames, slowed down to 8 fps)
    candleLightFrames = {}
    for i = 1, 4 do
        local lightFilename = "sprites/map/light" .. i .. ".png"
        if love.filesystem.getInfo(lightFilename) then
            local frame = love.graphics.newImage(lightFilename)
            frame:setFilter("nearest", "nearest")  -- Pixel art filtering
            table.insert(candleLightFrames, frame)
        end
    end

    -- Initialize candle animation state
    candleLightAnimationTime = 0
    candleLightFrameIndex = 1
    candleLightFrameDuration = 1 / 8  -- 8 fps (slower animation)
end

function loadToolSprites()
    -- Global table to store tool sprites
    toolSprites = {}

    -- Map tool IDs to sprite filenames
    local toolSpriteMap = {
        bone = "sprites/dice/bone.png",      -- transformer
        brain = "sprites/dice/brain.png",    -- tileLoader, tileInjector
        guts = "sprites/dice/guts.png",      -- extraHand, extraDiscard, knife
        void = "sprites/dice/void.png",      -- obsidianTransmuter, tenderTransmuter
        blood = "sprites/dice/blood.png"     -- demonReloader
    }

    -- Load each sprite
    for spriteType, filename in pairs(toolSpriteMap) do
        if love.filesystem.getInfo(filename) then
            toolSprites[spriteType] = love.graphics.newImage(filename)
        end
    end
end

function loadCupSprites()
    -- Global table to store cup animation frames
    cupSprites = {}

    -- Load 4 cup frames
    for i = 1, 4 do
        local filename = "sprites/dice/cup_" .. i .. ".png"
        if love.filesystem.getInfo(filename) then
            cupSprites[i] = love.graphics.newImage(filename)
        end
    end
end

-- Map tool IDs to their sprite types
function getToolSpriteType(toolId)
    local spriteMap = {
        transformer = "bone",
        tileLoader = "brain",
        tileInjector = "brain",
        extraHand = "guts",
        extraDiscard = "guts",
        knife = "guts",
        obsidianTransmuter = "void",
        tenderTransmuter = "void",
        demonReloader = "blood"
    }
    return spriteMap[toolId]
end