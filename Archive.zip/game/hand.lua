Hand = {}

function Hand.drawTiles(deck, count)
    local hand = {}
    
    for i = 1, math.min(count, #deck) do
        local tile = table.remove(deck, 1)
        if tile then
            tile.selected = false
            tile.placed = false
            table.insert(hand, tile)
        end
    end
    
    Hand.updatePositions(hand)
    return hand
end

function Hand.updatePositions(hand, skipSort)
    -- skipSort parameter allows disabling auto-sort for custom ordering
    skipSort = skipSort or false

    -- Always initialize animation properties first
    for i, domino in ipairs(hand) do
        if domino.selectScale == nil then
            domino.selectScale = 1.0
        end
        if domino.selectOffset == nil then
            domino.selectOffset = 0
        end
        -- Only initialize visualX/visualY if not already set AND not animating
        -- This prevents overwriting the off-screen position set by animateTilesDraw
        if (not domino.visualX or not domino.visualY) and not domino.isDrawing and not domino.isAnimating then
            local x, y = UI.Layout.getHandPosition(i - 1, #hand)
            domino.visualX = x
            domino.visualY = y
        end

        -- Initialize idle animation properties
        if domino.idleFloatOffset == nil then
            domino.idleFloatOffset = 0
        end
        if domino.idleRotation == nil then
            domino.idleRotation = 0
        end
        if domino.idleShadowOffset == nil then
            domino.idleShadowOffset = 0
        end
        if domino.idlePhase == nil then
            -- Give each tile a unique phase offset so they don't all move in sync
            domino.idlePhase = (i - 1) * 0.8
        end
    end

    -- Only recalculate positions if hand composition has changed
    local currentHandSignature = Hand.getHandSignature(hand)
    local handChanged = not hand._lastSignature or hand._lastSignature ~= currentHandSignature

    if handChanged then
        -- Only sort if not disabled (for custom ordering)
        if not skipSort then
            Hand.sortByValue(hand)
        end
        hand._lastSignature = currentHandSignature
    end

    -- Always update logical positions based on current order
    for i, domino in ipairs(hand) do
        local x, y = UI.Layout.getHandPosition(i - 1, #hand)
        domino.x = x
        domino.y = y

        -- Update visual position if not dragging or animating
        if not domino.isDragging and not domino.isAnimating then
            domino.visualX = x
            domino.visualY = y
        end
    end
end

function Hand.sortByValue(hand)
    -- Create a stable sort by using tile ID as secondary sort key
    -- This prevents tiles with same value from randomly switching positions
    table.sort(hand, function(a, b)
        local aValue = Domino.getValue(a)
        local bValue = Domino.getValue(b)

        if aValue == bValue then
            -- Use tile ID for stable sort when values are equal
            -- Safety check: ensure both tiles have IDs
            if a.id and b.id then
                return a.id < b.id
            end
            -- If IDs are missing, maintain current order
            return false
        end

        return aValue > bValue
    end)
end

function Hand.getHandSignature(hand)
    -- Create a signature based on tile IDs to detect composition changes
    local ids = {}
    for i, domino in ipairs(hand) do
        ids[i] = domino.id
    end
    return table.concat(ids, ",")
end

function Hand.update(dt)
    Hand.updatePositions(gameState.hand)
    Hand.updateDrawAnimations(gameState.hand, dt)
    Hand.updateDiscardAnimations(gameState.hand, dt)
    Hand.updateSortAnimations(gameState.hand, dt)
    Hand.updateIdleAnimations(gameState.hand, dt)
end

function Hand.updateIdleAnimations(hand, dt)
    local time = love.timer.getTime()

    for i, domino in ipairs(hand) do
        -- Only apply idle animations if tile is not being dragged, selected, drawing, or discarding
        if not domino.isDragging and not domino.selected and not domino.isDrawing and not domino.isDiscarding then
            -- Floating animation - 3px range, 2.5 second cycle with unique phase offset
            local floatPhase = time * 2.5 + domino.idlePhase
            domino.idleFloatOffset = math.sin(floatPhase) * 3
            
            -- Rotation animation - 1.5 degree range, 4 second cycle with different phase
            local rotationPhase = time * 1.57 + domino.idlePhase * 1.3  -- 1.57 ≈ π/2 for different timing
            domino.idleRotation = math.sin(rotationPhase) * 0.026  -- 0.026 radians ≈ 1.5 degrees
            
            -- Shadow offset follows main motion but dampened
            domino.idleShadowOffset = domino.idleFloatOffset * 0.3
        else
            -- Reset idle animations when tile is interacted with
            domino.idleFloatOffset = 0
            domino.idleRotation = 0
            domino.idleShadowOffset = 0
        end
    end
end

function Hand.getTileAt(hand, x, y)
    for i, domino in ipairs(hand) do
        if Domino.containsPoint(domino, x, y) then
            return domino, i
        end
    end
    return nil, nil
end

function Hand.selectTile(hand, tile)
    -- Obsidian tiles cannot be selected/discarded
    if tile.tileType == "obsidian" then
        -- Show feedback that obsidian tiles can't be discarded
        if UI.Animation and UI.Animation.createFloatingText then
            UI.Animation.createFloatingText("OBSIDIAN TILES CANNOT BE DISCARDED",
                gameState.screen.width / 2,
                gameState.screen.height / 2 - UI.Layout.scale(100), {
                color = {0.125, 0.145, 0.263, 1},
                fontSize = "small",
                duration = 1.0,
                riseDistance = 20,
                startScale = 0.8,
                endScale = 1.0,
                easing = "easeOutQuart"
            })
        end
        return
    end

    local wasSelected = tile.selected
    tile.selected = not tile.selected

    if tile.selected and not wasSelected then
        -- Punch out animation and move up
        tile.selectScale = 1.0
        tile.selectOffset = 0
        
        -- Punch out effect - scale up briefly then back down
        UI.Animation.animateTo(tile, {
            selectScale = 1.15
        }, 0.1, "easeOutBack", function()
            UI.Animation.animateTo(tile, {
                selectScale = 1.0
            }, 0.15, "easeOutBack")
        end)
        
        -- Move up with vertical offset
        UI.Animation.animateTo(tile, {
            selectOffset = -UI.Layout.scale(20)
        }, 0.2, "easeOutBack")
        
    elseif not tile.selected and wasSelected then
        -- Deselect animation - move back down
        UI.Animation.animateTo(tile, {
            selectOffset = 0,
            selectScale = 1.0
        }, 0.15, "easeOutBack")
    end
end

function Hand.clearSelection(hand)
    for _, domino in ipairs(hand) do
        if domino.selected then
            domino.selected = false
            -- Reset selection animations
            UI.Animation.animateTo(domino, {
                selectOffset = 0,
                selectScale = 1.0
            }, 0.15, "easeOutBack")
        end
    end
end

function Hand.hasSelectedTiles(hand)
    for _, domino in ipairs(hand) do
        if domino.selected then
            return true
        end
    end
    return false
end

function Hand.getSelectedTiles(hand)
    local selected = {}
    for _, domino in ipairs(hand) do
        if domino.selected then
            table.insert(selected, domino)
        end
    end
    return selected
end

function Hand.removeSelectedTiles(hand)
    local remaining = {}
    local removed = {}

    for _, domino in ipairs(hand) do
        if domino.selected then
            -- Clean up animations for removed tiles
            UI.Animation.stopAll(domino)
            table.insert(removed, domino)
        else
            table.insert(remaining, domino)
        end
    end

    for i = 1, #hand do
        hand[i] = nil
    end

    for i, domino in ipairs(remaining) do
        hand[i] = domino
    end

    -- Animate remaining tiles to their new positions smoothly
    Hand.animateRemainingTilesToNewPositions(hand)

    -- Update hand signature to prevent auto-sorting after removal
    hand._lastSignature = Hand.getHandSignature(hand)

    return removed
end

-- Animate remaining tiles smoothly to their new positions after removal
function Hand.animateRemainingTilesToNewPositions(hand)
    -- Update logical positions
    Hand.updatePositions(hand, true)

    -- Animate visual positions to match logical positions
    for i, domino in ipairs(hand) do
        if not domino.isDrawing and not domino.isDiscarding then
            local targetX = domino.x
            local targetY = domino.y

            -- Only animate if position actually changed
            if math.abs(domino.visualX - targetX) > 1 then
                domino.isAnimating = true  -- Mark as animating to prevent updatePositions from overwriting
                UI.Animation.animateTo(domino, {
                    visualX = targetX,
                    visualY = targetY
                }, 0.25, "easeOutQuart", function()
                    domino.isAnimating = false  -- Clear flag when done
                end)
            end
        end
    end
end

function Hand.addTiles(hand, tiles)
    for _, tile in ipairs(tiles) do
        -- Check if this tile ID already exists in the hand
        local alreadyExists = false
        for _, existingTile in ipairs(hand) do
            if existingTile.id == tile.id then
                alreadyExists = true
                break
            end
        end

        -- Only add if it doesn't already exist
        if not alreadyExists then
            tile.selected = false
            tile.placed = false
            table.insert(hand, tile)
        end
    end
    -- Skip sorting when adding tiles to preserve custom order
    Hand.updatePositions(hand, true)
end

function Hand.refillHand(hand, deck, targetCount)
    local needed = targetCount - #hand
    if needed <= 0 then
        return 0
    end

    -- Draw tiles directly without positioning them
    local drawnTiles = {}
    for i = 1, math.min(needed, #deck) do
        local tile = table.remove(deck, 1)
        if tile then
            tile.selected = false
            tile.placed = false
            table.insert(drawnTiles, tile)
        end
    end

    Hand.addTiles(hand, drawnTiles)

    return #drawnTiles, drawnTiles
end

function Hand.isEmpty(hand)
    return #hand == 0
end

function Hand.size(hand)
    return #hand
end

function Hand.animateTilesDraw(hand, startDelay, specificTiles)
    startDelay = startDelay or 0

    -- Get off-screen right position
    local offScreenX = gameState.screen.width + UI.Layout.scale(200)

    -- If specific tiles provided, only animate those
    local tilesToAnimate = specificTiles or hand

    -- Create a set of tile IDs to animate for quick lookup
    local animateSet = {}
    if specificTiles then
        for _, tile in ipairs(specificTiles) do
            animateSet[tile.id] = true
        end
    end

    for i, tile in ipairs(hand) do
        -- Only animate if this tile should be animated
        local shouldAnimate = not specificTiles or animateSet[tile.id]

        if shouldAnimate then
            -- Calculate final position
            local targetX, targetY = UI.Layout.getHandPosition(i - 1, #hand)

            -- IMPORTANT: Set visual position off-screen FIRST, before marking as animating
            -- This prevents Hand.updatePositions from setting it to final position
            tile.visualX = offScreenX
            tile.visualY = targetY

            -- NOW mark tile as drawing and animating
            tile.isDrawing = true
            tile.isAnimating = true

            -- Set logical position
            tile.x = targetX
            tile.y = targetY

            -- Calculate staggered delay - leftmost tile (index 0) appears first
            -- Since tiles are sorted high to low value, index 0 is highest value (leftmost)
            local tileDelay = startDelay + (i - 1) * 0.08

            -- Animate from right to final position with delay
            local animStart = love.timer.getTime() + tileDelay
            tile.drawAnimStart = animStart
            tile.drawAnimDuration = 0.4
            tile.drawStartX = offScreenX
            tile.drawTargetX = targetX
        else
            -- Ensure non-animated tiles have correct visual position
            if not tile.isAnimating and not tile.isDragging then
                local targetX, targetY = UI.Layout.getHandPosition(i - 1, #hand)
                tile.visualX = targetX
                tile.visualY = targetY
            end
        end
    end
end

function Hand.updateDrawAnimations(hand, dt)
    local currentTime = love.timer.getTime()

    for i, tile in ipairs(hand) do
        if tile.isDrawing and tile.drawAnimStart then
            local elapsed = currentTime - tile.drawAnimStart

            if elapsed >= 0 then
                local progress = math.min(elapsed / tile.drawAnimDuration, 1.0)

                -- Use easeOutQuart for smooth deceleration with minimal overshoot
                local easedProgress = 1 - math.pow(1 - progress, 4)

                -- Update visual position
                tile.visualX = tile.drawStartX + (tile.drawTargetX - tile.drawStartX) * easedProgress

                if progress >= 1.0 then
                    -- Animation complete
                    tile.isDrawing = false
                    tile.isAnimating = false
                    tile.drawAnimStart = nil
                    tile.drawAnimDuration = nil
                    tile.drawStartX = nil
                    tile.drawTargetX = nil
                    tile.visualX = tile.x

                    -- Play placement sound when tile arrives at position
                    if UI.Audio and UI.Audio.playTilePlaced then
                        UI.Audio.playTilePlaced()
                    end
                end
            end
        end
    end
end

function Hand.animateDiscard(tiles, onComplete)
    if #tiles == 0 then
        if onComplete then onComplete() end
        return
    end

    local completedCount = 0
    local targetY = gameState.screen.height + UI.Layout.scale(100)

    for i, tile in ipairs(tiles) do
        tile.isDiscarding = true
        tile.isAnimating = true

        -- Animate downward off screen
        UI.Animation.animateTo(tile, {
            visualY = targetY
        }, 0.3, "easeInQuart", function()
            tile.isDiscarding = false
            completedCount = completedCount + 1

            -- Call completion callback when all tiles finish
            if completedCount == #tiles and onComplete then
                onComplete()
            end
        end)
    end
end

function Hand.animateAllHandDiscard(hand, onComplete)
    if #hand == 0 then
        if onComplete then onComplete() end
        return
    end

    local completedCount = 0
    local totalTiles = #hand
    local targetY = gameState.screen.height + UI.Layout.scale(100)

    for i, tile in ipairs(hand) do
        tile.isDiscarding = true
        tile.isAnimating = true

        -- Small stagger for visual polish using animation system's built-in delay
        local staggerDelay = (i - 1) * 0.05
        local animDuration = 0.3

        -- Store animation start time for staggered execution
        tile.discardAnimStart = love.timer.getTime() + staggerDelay
        tile.discardAnimDuration = animDuration
        tile.discardStartY = tile.visualY
        tile.discardTargetY = targetY
        tile.discardOnCompleteCallback = function()
            tile.isDiscarding = false
            completedCount = completedCount + 1

            if completedCount == totalTiles and onComplete then
                onComplete()
            end
        end
    end
end

function Hand.updateDiscardAnimations(hand, dt)
    local currentTime = love.timer.getTime()

    for i, tile in ipairs(hand) do
        if tile.isDiscarding and tile.discardAnimStart then
            local elapsed = currentTime - tile.discardAnimStart

            if elapsed >= 0 then
                local progress = math.min(elapsed / tile.discardAnimDuration, 1.0)

                -- Use easeInQuart for smooth acceleration downward
                local easedProgress = progress * progress * progress * progress

                -- Update visual position
                tile.visualY = tile.discardStartY + (tile.discardTargetY - tile.discardStartY) * easedProgress

                if progress >= 1.0 then
                    -- Animation complete
                    tile.discardAnimStart = nil
                    tile.discardAnimDuration = nil
                    tile.discardStartY = nil
                    tile.discardTargetY = nil

                    -- Call completion callback
                    if tile.discardOnCompleteCallback then
                        tile.discardOnCompleteCallback()
                        tile.discardOnCompleteCallback = nil
                    end
                end
            end
        end
    end
end

-- Get the insertion index for a dragged tile based on hover position
function Hand.getInsertionIndex(hand, draggedTile, dragX)
    if #hand <= 1 then
        return 1
    end

    -- Build a list of visible tiles (excluding dragged) with their 6-tile closed positions
    local visibleTiles = {}
    for i, tile in ipairs(hand) do
        if tile ~= draggedTile then
            table.insert(visibleTiles, tile)
        end
    end

    -- Calculate where each tile would be in the 6-tile closed layout
    -- and find which position the drag X corresponds to
    local insertIndex = 1

    for i, tile in ipairs(visibleTiles) do
        local tileX, _ = UI.Layout.getHandPosition(i - 1, #visibleTiles)

        -- If dragX is past this tile's center, we should insert after it
        if dragX > tileX then
            insertIndex = i + 1
        end
    end

    return insertIndex
end

-- Insert a tile at a specific index in the hand
function Hand.insertTileAt(hand, tile, targetIndex)
    -- Find current index of tile
    local currentIndex = nil
    for i, t in ipairs(hand) do
        if t == tile then
            currentIndex = i
            break
        end
    end

    if not currentIndex then
        -- Tile not in hand, just insert at target
        table.insert(hand, targetIndex, tile)
    else
        -- Remove from current position
        table.remove(hand, currentIndex)

        -- Adjust target index if needed (when moving right, index shifts)
        local adjustedIndex = targetIndex
        if currentIndex < targetIndex then
            adjustedIndex = targetIndex - 1
        end

        -- Insert at new position
        table.insert(hand, adjustedIndex, tile)
    end

    -- Update positions without sorting
    Hand.updatePositions(hand, true)
end

-- Animate tiles to sorted positions with satisfying arc motion
function Hand.animateSortTiles(hand)
    -- Store current order before sorting
    local oldIndices = {}
    for i, tile in ipairs(hand) do
        oldIndices[tile.id] = i
    end

    -- Sort the hand by value (highest to lowest)
    Hand.sortByValue(hand)

    -- Update logical positions to sorted order
    for i, tile in ipairs(hand) do
        local targetX, targetY = UI.Layout.getHandPosition(i - 1, #hand)
        tile.x = targetX
        tile.y = targetY
    end

    -- Animate each tile to its new position with arc if moving >1 spot
    for i, tile in ipairs(hand) do
        local oldIndex = oldIndices[tile.id]
        local newIndex = i
        local distanceMoved = math.abs(newIndex - oldIndex)

        -- Only animate if position changed
        if distanceMoved > 0 then
            local targetX = tile.x
            local targetY = tile.y
            local startX = tile.visualX
            local startY = tile.visualY

            tile.isAnimating = true
            tile.isSorting = true

            -- If moving more than 1 spot, add arc animation
            if distanceMoved > 1 then
                -- Arc animation with parabolic trajectory
                local arcHeight = UI.Layout.scale(30 + distanceMoved * 10) -- Higher arc for longer distances
                local duration = 0.35

                -- Create custom animation with arc
                tile.sortAnimStart = love.timer.getTime()
                tile.sortAnimDuration = duration
                tile.sortStartX = startX
                tile.sortStartY = startY
                tile.sortTargetX = targetX
                tile.sortTargetY = targetY
                tile.sortArcHeight = arcHeight
            else
                -- Simple straight animation for 1-spot moves
                UI.Animation.animateTo(tile, {
                    visualX = targetX,
                    visualY = targetY
                }, 0.25, "easeOutBack", function()
                    tile.isAnimating = false
                    tile.isSorting = false

                    -- Play placement sound when tile arrives at sorted position
                    if UI.Audio and UI.Audio.playTilePlaced then
                        UI.Audio.playTilePlaced()
                    end
                end)
            end
        end
    end

    -- Update hand signature to prevent auto-resorting during animation
    hand._lastSignature = Hand.getHandSignature(hand)
end

-- Update sort animations (called from Hand.update)
function Hand.updateSortAnimations(hand, dt)
    local currentTime = love.timer.getTime()

    for i, tile in ipairs(hand) do
        if tile.isSorting and tile.sortAnimStart then
            local elapsed = currentTime - tile.sortAnimStart

            if elapsed >= 0 then
                local progress = math.min(elapsed / tile.sortAnimDuration, 1.0)

                -- Use easeOutBack for satisfying bounce
                local t = progress
                local c1 = 1.70158
                local c3 = c1 + 1
                local easedProgress = 1 + c3 * math.pow(t - 1, 3) + c1 * math.pow(t - 1, 2)

                -- Linear interpolation for X
                tile.visualX = tile.sortStartX + (tile.sortTargetX - tile.sortStartX) * easedProgress

                -- Parabolic arc for Y (peaks at midpoint)
                local linearY = tile.sortStartY + (tile.sortTargetY - tile.sortStartY) * easedProgress
                local arcOffset = -tile.sortArcHeight * (4 * progress * (1 - progress)) -- Parabola: peaks at 0.5
                tile.visualY = linearY + arcOffset

                if progress >= 1.0 then
                    -- Animation complete
                    tile.isAnimating = false
                    tile.isSorting = false
                    tile.sortAnimStart = nil
                    tile.sortAnimDuration = nil
                    tile.sortStartX = nil
                    tile.sortStartY = nil
                    tile.sortTargetX = nil
                    tile.sortTargetY = nil
                    tile.sortArcHeight = nil
                    tile.visualX = tile.x
                    tile.visualY = tile.y

                    -- Play placement sound when tile arrives at sorted position
                    if UI.Audio and UI.Audio.playTilePlaced then
                        UI.Audio.playTilePlaced()
                    end
                end
            end
        end
    end
end

return Hand